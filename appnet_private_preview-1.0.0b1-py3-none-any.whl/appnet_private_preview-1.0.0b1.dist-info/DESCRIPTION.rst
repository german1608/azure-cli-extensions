# Azure CLI AppnetPreview Extension #
This is an extension to Azure CLI to manage AppnetPreview resources.

## How to use ##
Please add commands usage here.

.. :changelog:

Release History
===============

1.0.0b1
++++++
* Initial release.
